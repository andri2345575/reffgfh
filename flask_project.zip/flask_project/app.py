# -*- coding: utf-8 -*-
"""
Лабораторна робота №9. Створення веб-додатку на Flask.
Виконав: Остафій Андрій, група ПЦТ-31.

Головний файл застосунку: містить маршрути (routes) та логіку обробки запитів.
"""
from datetime import datetime

from flask import Flask, render_template, request, redirect, url_for, flash

# Створюємо об'єкт застосунку Flask
app = Flask(__name__)
# Секретний ключ потрібен для flash-повідомлень (зберігаються у сесії)
app.secret_key = "lab9-flask-secret-key"

# Список зареєстрованих користувачів (зберігається в пам'яті, поки працює сервер)
users = []

# Дані для сторінки "Галерея": назва, опис і файл зображення з папки static/img
gallery_items = [
    {"title": "Карпати", "text": "Гірські вершини Українських Карпат.", "image": "mountains.svg"},
    {"title": "Івано-Франківськ", "text": "Затишне місто з багатою історією.", "image": "city.svg"},
    {"title": "Ріка Прут", "text": "Швидка гірська річка Прикарпаття.", "image": "river.svg"},
    {"title": "Програмування", "text": "Python + Flask = власний вебсайт.", "image": "code.svg"},
]


@app.context_processor
def inject_year():
    """Передає поточний рік у всі шаблони (для підвалу сайту)."""
    return {"current_year": datetime.now().year}


@app.route("/")
def home():
    """Головна сторінка."""
    return render_template("index.html", users_count=len(users))


@app.route("/register", methods=["GET", "POST"])
def register():
    """Форма реєстрації: GET — показати форму, POST — обробити дані."""
    if request.method == "POST":
        # Отримуємо дані з HTML-форми через request.form
        name = request.form["name"].strip()
        email = request.form["email"].strip()
        message = request.form["message"].strip()

        # Проста перевірка: поля не повинні бути порожніми
        if not name or not email or not message:
            flash("Будь ласка, заповніть усі поля форми.")
            return redirect(url_for("register"))

        users.append({
            "name": name,
            "email": email,
            "message": message,
            "date": datetime.now().strftime("%d.%m.%Y %H:%M"),
        })
        # Передаємо змінні з Python у шаблон як іменовані аргументи
        return render_template("result.html", name=name, email=email, message=message)

    return render_template("register.html")


@app.route("/users")
def show_users():
    """Список зареєстрованих користувачів."""
    return render_template("users.html", users=users)


@app.route("/gallery")
def gallery():
    """Додаткова сторінка "Галерея"."""
    return render_template("gallery.html", items=gallery_items)


@app.route("/about")
def about():
    """Сторінка "Про проєкт"."""
    return render_template("about.html")


@app.errorhandler(404)
def page_not_found(error):
    """Власна сторінка помилки 404."""
    return render_template("404.html"), 404


if __name__ == "__main__":
    # debug=True — режим налагодження: автоматичне перезавантаження та детальні помилки
    app.run(debug=True)
